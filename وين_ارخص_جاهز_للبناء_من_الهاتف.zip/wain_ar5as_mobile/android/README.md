# وين أرخص؟ — Android

هذا مشروع Android Studio حقيقي يغلّف نسخة الويب الحالية داخل WebView، مع دعم JavaScript وLocal Storage وRTL.

## البناء
1. افتح مجلد `android` في Android Studio.
2. انتظر Gradle Sync.
3. اختر جهاز Android أو Emulator.
4. Run أو Build > Build APK(s).

يتطلب Android Studio وAndroid SDK مثبتين على جهاز البناء.
