# وين أرخص؟ — حزمة Android + iPhone

تم تحويل نسخة الويب الحالية إلى مشروعين:
- `android/` مشروع Android Studio حقيقي يستخدم WebView مع الملفات المحلية.
- `ios/` مشروع iOS/Xcode يستخدم WKWebView مع الملفات المحلية.

هذه الحزمة هي **مصدر التطبيقات** وليست APK/IPA موقّعًا. بناء APK يحتاج Android Studio/SDK، وبناء IPA يحتاج macOS + Xcode + Apple signing.

الواجهة الحالية ما زالت نموذجًا تجريبيًا محليًا: لا يوجد Backend أو SMS OTP أو دفع حقيقي.
