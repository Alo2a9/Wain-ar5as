# وين أرخص؟ — iPhone / iOS

هذا مشروع Swift/WKWebView مرفق معه واجهة التطبيق الحالية.

## البناء
- افتح المشروع في Xcode على macOS.
- اختر Signing Team.
- Build/Run على iPhone أو Simulator.
- وللنشر على App Store يلزم Apple Developer account وتهيئة signing.

ملاحظة: بيئة ChatGPT الحالية لا تحتوي macOS/Xcode، لذلك لم أزعم أن IPA مبني أو موقّع.
